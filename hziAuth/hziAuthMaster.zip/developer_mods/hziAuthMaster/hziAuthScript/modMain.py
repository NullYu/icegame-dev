# -*- coding: utf-8 -*-
# @Author : uni_kevin(可乐)

from mod.common.mod import Mod
import mod.server.extraMasterApi as extraMasterApi

@Mod.Binding(name='HziAuth', version='1.0.0')
class HziAuth(object):

    @Mod.InitMaster()
    def ServerInit(self):
        extraMasterApi.RegisterSystem('HziAuth', 'HziAuthMaster', 'hziAuthScript.hziAuthMaster.HziAuthMaster')

    @Mod.DestroyMaster()
    def ServerDestroy(self):
        pass