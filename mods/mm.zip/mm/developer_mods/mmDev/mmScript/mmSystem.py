# -*- coding: utf-8 -*-
# 上面这行是让这个文件按utf-8进行编码，这样就可以在注释中写中文了

# 这行import到的是引擎服务端的API模块
import server.extraServerApi as serverApi
import time
import math
import random
import datetime
import json
import lobbyGame.netgameApi as lobbyGameApi
import apolloCommon.commonNetgameApi as commonNetgameApi
import swScript.swConsts as c
import apolloCommon.mysqlPool as mysqlPool

# 获取引擎服务端System的基类，System都要继承于ServerSystem来调用相关函数
ServerSystem = serverApi.GetServerSystemCls()

initScoreboard = False

scoreboard = {}

# 在modMain中注册的Server System类
class swServerSys(ServerSystem):
    # ServerSystem的初始化函数
    def __init__(self, namespace, systemName):
        # 首先调用父类的初始化函数
        ServerSystem.__init__(self, namespace, systemName)
        self.ListenEvents()
        self.consts = c
        lobbyGameApi.ShieldPlayerJoinText(True)

        self.waiting = []
        self.status = 0
        self.playing = {}
        self.timer = 0
        self.kills = {}
        self.countdown = 180

        self.arenaIsInit = False
        self.init = False

    ##############UTILS##############

    def playStartAnimation(self):
        for player in serverApi.GetPlayerList():
            commonNetgameApi.AddTimer(0.2, lambda p: self.sendTitle('§d§l开      战', 1, p), player)
            commonNetgameApi.AddTimer(0.4, lambda p: self.sendTitle('§d§l开     战', 1, p), player)
            commonNetgameApi.AddTimer(0.6, lambda p: self.sendTitle('§d§l开    战', 1, p), player)
            commonNetgameApi.AddTimer(0.8, lambda p: self.sendTitle('§d§l开   战', 1, p), player)
            commonNetgameApi.AddTimer(1.0, lambda p: self.sendTitle('§d§l开  战', 1, p), player)
            commonNetgameApi.AddTimer(1.2, lambda p: self.sendTitle('§d§l开 战', 1, p), player)
            commonNetgameApi.AddTimer(1.4, lambda p: self.sendTitle('§d§l开战', 1, p), player)
            commonNetgameApi.AddTimer(1.4, lambda p: self.sendTitle('§e不要被杀手刺中！', 2, p), player)

    def rank(self, d):
        mComp = 0
        for item in d:
            if (not mComp in d or d[item] > d[mComp]) and item in self.teams:
                mComp = item
        return mComp

    def getIfLegalBreak(self, pos):
        for player in self.blocks:
            if pos in self.blocks[player]:
                return True
        return False

    def getCountInList(self, key, li):
        count = 0
        for item in li:
            if key == li[item]:
                count += 1
        return count

    def getMatchingList(self, key, object):
        ret = []
        for item in object:
            if key == object[item]:
                ret.append(item)
        return ret

    def sendCmd(self, cmd, playerId):
        comp = serverApi.GetEngineCompFactory().CreateCommand(serverApi.GetLevelId())
        comp.SetCommand(cmd, playerId)

    def sendTitle(self, title, type, playerId):
        if (type == 1):
            self.sendCmd("/title @s title " + title, playerId)
        elif (type == 2):
            self.sendCmd("/title @s subtitle " + title, playerId)
        elif (type == 3):
            self.sendCmd("/title @s actionbar " + title, playerId)
        else:
            print 'invalid params for call/sendTitle(): type'

    def forceSelect(self, slot, playerId):
        comp = serverApi.GetEngineCompFactory().CreatePlayer(playerId)
        comp.ChangeSelectSlot(slot)

    def sendMsg(self, msg, playerId):
        comp = serverApi.GetEngineCompFactory().CreateMsg(playerId)
        comp.NotifyOneMessage(playerId, msg, "§f")

    def sendMsgToAll(self, msg):
        for player in serverApi.GetPlayerList():
            self.sendMsg(msg, player)

    def sendCmdToAll(self, msg):
        for player in serverApi.GetPlayerList():
            self.sendCmd(msg, player)

    def board(self, player, msg):
        utilsSystem = serverApi.GetSystem('utils', 'utilsSystem')
        utilsSystem.TextBoard(player, True, msg)

    def InitArena(self):
        print 'ARENA INIT!!!'



    def setPos(self, playerId, pos):
        comp = serverApi.GetEngineCompFactory().CreatePos(playerId)
        re = comp.SetFootPos(pos)
        return re

    def dist(self, x1, y1, z1, x2, y2, z2):
        """
        运算3维空间距离，返回float
        """
        p = ((x2 - x1) ** 2 + (y2 - y1) ** 2 + (z2 - z1) ** 2) ** 0.5
        re = float('%.1f' % p)
        return re

    def updateServerStatus(self, status):
        args = {
            'sid': lobbyGameApi.GetServerId(),
            'value': status,
            'count': len(serverApi.GetPlayerList())
        }
        serverId = lobbyGameApi.GetServerId()
        print 'init recordsid'
        self.RequestToServiceMod("service_bw", "RecordSidEvent", args)

    def epoch2Datetime(self, epoch):
        ts = datetime.datetime.fromtimestamp(int(epoch)+0)
        return ts.strftime('%Y-%m-%d %H:%M:%S')



    #################################

    def ListenEvents(self):
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "DelServerPlayerEvent", self, self.OnDelServerPlayer)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "AddServerPlayerEvent", self, self.OnAddServerPlayer)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "PlayerAttackEntityEvent", self, self.OnPlayerAttackEntity)


        gameComp = serverApi.GetEngineCompFactory().CreateGame(serverApi.GetLevelId())
        gameComp.SetCanBlockSetOnFireByLightning(False)
        gameComp.SetCanActorSetOnFireByLightning(False)

        comp = serverApi.GetEngineCompFactory().CreateGame(serverApi.GetLevelId())
        ruleDict = {
            'option_info': {
                'natural_regeneration': True,  # 自然生命恢复
                'immediate_respawn': True  # 作弊开启
            },
            'cheat_info': {
                'always_day': True,  # 终为白日
                'mob_griefing': True,  # 生物破坏方块
                'keep_inventory': False,  # 保留物品栏
                'weather_cycle': False,  # 天气更替
                'mob_spawn': False,  # 生物生成
            }
        }
        comp.SetGameRulesInfoServer(ruleDict)
        comp.SetGameDifficulty(2)
        lobbyGameApi.ShieldPlayerJoinText(True)
        commonNetgameApi.AddRepeatedTimer(1.0, self.tick)
        commonNetgameApi.AddRepeatedTimer(1.0, self.BoardTick)
        gameComp = serverApi.GetEngineCompFactory().CreateGame(serverApi.GetLevelId())
        gameComp.SetCanBlockSetOnFireByLightning(False)
        gameComp.SetCanActorSetOnFireByLightning(False)

        def b():
            args = {
                'sid': lobbyGameApi.GetServerId(),
                'value': 0
            }
            serverId = lobbyGameApi.GetServerId()
            print 'init recordsid'
            self.RequestToServiceMod("service_sw", "RecordSidEvent", args)
        commonNetgameApi.AddTimer(8.0, b)

    def OnAddServerPlayer(self, data):
        playerId  = data['id']
        if self.status == 0:
            self.waiting.append(playerId)
            commonNetgameApi.AddTimer(6.0, lambda p: self.sendMsg('§a您来的正是时候！请等待游戏开始', p), playerId)
            self.setPos(playerId, c.lobbyPos)
            utilsSystem = serverApi.GetSystem('utils', 'utilsSystem')
            utilsSystem.SetPlayerSpectate(playerId, False)
        elif self.status == 1:
            utilsSystem = serverApi.GetSystem('utils', 'utilsSystem')
            utilsSystem.SetPlayerSpectate(playerId, True)


    def OnDelServerPlayer(self, data):
        playerId = data['id']
        if playerId in self.waiting:
            self.waiting.pop(self.waiting.index(playerId))
        if playerId in self.players:
            self.playing.pop(self.players.index(playerId))

    def OnPlayerAttackEntity(self, data):
        playerId = data['playerId']
        victimId = data['vicitmId']
        data['damage'] = 0

        if self.status != 1:
            data['cancel'] = True
            return

        if playerId not in self.playing or victimId not in self.playing or self.playing[playerId] != 2:
            data['cancel'] = True
            return

        if self.playing[playerId] == 2:
            self.sendTitle("§b", 1, playerId)
            self.sendTitle("§a干得漂亮！", 2, playerId)
            self.sendMsg('/playsound mob.skeleton.hurt @a', playerId)
            self.Elim(victimId, 2)
            self.sendCmd('/clear', victimId)

            role = self.playing[victimId]
            if role == 1:
                self.sendMsgToAll('§c§l一名侦探被击杀了！§t他的弓已经掉落。')
                serverApi.GetEngineCompFactory().CreateItem(serverApi.GetLevelId()).SpawnItemToLevel({
                    'itemName': 'minecraft:bow',
                    'count': 1
                }, 0, serverApi.GetEngineCompFactory().CreatePos(victimId).GetFootPos())
                self.sendMsg('/summon lightning_bolt', victimId)

    def Elim(self, playerId, type):
        self.sendCmd('/effect @s blindness 3 1 true', playerId)
        self.sendCmd('/effect @s slowness 3 255 true', playerId)
        self.sendCmd('/effect @s invisibility 3 1 true', playerId)
        if type == 2:
            self.sendTitle("§l§c您被杀手刺中了", 1, playerId)
            self.sendTitle("您已被淘汰", 2, playerId)

        utilsSystem = serverApi.GetSystem('utils', 'utilsSystem')
        utilsSystem.SetPlayerSpectate(playerId, True)

        self.playing.pop(playerId)

    def CheckForWin(self, data):
        if len(self.playing) == 1:
            self.status = 2
            winner = self.playing.keys()[0]

            utilsSystem = serverApi.GetSystem('utils', 'utilsSystem')
            utilsSystem.ShowWinBanner(winner)

            def a():
                self.status = 0
                self.InitArena()
                self.updateServerStatus(self.status)
                for p in serverApi.GetPlayerList():
                    self.RequestToServiceMod("bw", "RequestMatchmakingEvent", {
                        'playerId': p,
                        'mode': commonNetgameApi.GetServerType()
                    }, self.BwMatchmakingCallback, 2)

                self.countdown = 180

                rebootSystem = serverApi.GetSystem('reboot', 'rebootSystem')
                rebootSystem.DoReboot(False)

            commonNetgameApi.AddTimer(15.0, a)

    def BwMatchmakingCallback(self, suc, data):
        if not suc:
            print 'OnCallback timeout'
            return
        value = data['value']
        playerId = data['playerId']

        if value == 0:
            self.sendMsg("§c§l无法分配房间：§r没有开放的房间可供您加入。稍后将您传送回主城。", playerId)
            def a():
                transData = {'position': [1, 2, 3]}
                lobbyGameApi.TransferToOtherServer(playerId, 'lobby', json.dumps(transData))
            commonNetgameApi.AddTimer(3.0, a)
            return
        elif value == 1:
            sid = data['sid']
            self.sendMsg("§3即将将您传送至%s-%s，请稍等片刻" % (commonNetgameApi.GetServerType(), sid), playerId)
            def a():
                transData = {'position': [1, 2, 3]}
                lobbyGameApi.TransferToOtherServerById(playerId, sid, json.dumps(transData))
            commonNetgameApi.AddTimer(1.0, a)

    def BoardTick(self):
        utilsSystem = serverApi.GetSystem('utils', 'utilsSystem')
        do = utilsSystem.TextBoard
        if self.status == 0:
            for player in serverApi.GetPlayerList():
                self.sendCmd('/gamerule sendcommandfeedback false', player)
                self.sendCmd('/gamerule showdeathmessages false', player)
                do(player, True, """
§e§lICE§a_§bGAME§r§l -> §e密室§d杀手§r

§7满%s人即可开始游戏§r
§l目前人数: §e%s人
§f倒计时: §c%s秒

§r§e在ICE_GAME体验空岛战争
§7%s
""" % (c.startCountdown, len(self.waiting), self.countdown, self.epoch2Datetime(time.time())))
        elif self.status == 1:
            for player in serverApi.GetPlayerList():
                do(player, True, """
§e§lICE§a_§bGAME§r§l -> §e密室§d杀手§r
§b比赛已进行%s§r

§e§l场上还剩§b%s§e名玩家

§r§e在ICE_GAME体验密室杀手
""" % (datetime.timedelta(seconds=self.timer), len(self.playing)))

    def tick(self):
        # per tick updates
        count = len(serverApi.GetPlayerList())

        if self.status == 0:
            for player in serverApi.GetPlayerList():
                self.sendCmd('/gamemode a @s', player)
            print 'countdown=%s' % self.countdown
            self.timer = 0
            if count < c.startCountdown:
                pass
            elif c.startCountdown <= count <= 12:
                self.countdown -= 1
                for player in serverApi.GetPlayerList():
                    self.sendTitle("§e§l%s" % self.countdown, 1, player)
                    self.sendTitle("游戏即将开始", 2, player)
            if count == 12 and self.countdown > 15:
                self.countdown = 15
            if self.countdown < 180 and count < c.startCountdown:
                self.sendMsgToAll("§c§l人数不够，倒计时取消！")
                self.countdown = 180
            if self.countdown == 8:
                self.InitArena()
            if self.countdown == 0:
                print 'starting!'
                self.start()
                self.status = 1
        elif self.status == 1:
            self.timer += 1

            if 3 < self.timer < 13:
                for player in self.playing:
                    self.sendTitle("§b", 1, player)
                    self.sendTitle("§l§4杀手将在%s秒后获得凶器" % (10-(self.timer-3)), 2, player)
            elif self.timer == 13:
                for player in self.playing:
                    self.sendTitle("§b", 1, player)
                    self.sendTitle("§l§c杀手已获得凶器，快逃！" % (10-(self.timer-3)), 2, player)

                murder = self.getMatchingList(2, self.playing)[0]
                self.sendCmd('/give @s iron_sword', murder)

        elif self.status == 2:
            for player in serverApi.GetPlayerList():
                self.sendCmd('/gamemode a @s', player)

        self.updateServerStatus(self.status)

        print 'isinit %s' % self.arenaIsInit

    def start(self):
        self.timer = 0
        for player in self.waiting:
            self.waiting.pop(self.waiting.index(player))
            self.playing[player] = 3
            self.setPos(player, c.startPos)
        self.playing[random.choice(self.playing.keys())] = 1
        self.playing[random.choice(self.playing.keys())] = 2

        for player in self.playing:
            role = self.playing[player]
            if role == 1:
                self.sendTitle("§b§l侦探", 1, player)
                self.sendTitle("找出杀手，并使用弓箭将其击毙", 2, player)
                self.sendCmd('/give @s bow', player)
                self.sendCmd('/give @s arrow', player)
            elif role == 2:
                self.sendTitle("§c§l杀手", 1, player)
                self.sendTitle("杀死所有人，获得胜利", 2, player)
            else:
                self.sendTitle("§l平民", 1, player)
                self.sendTitle("收集金条购买弓箭，小心杀手！", 2, player)

            self.sendCmd('/playsound block.bell.hit', player)

